import sys
import os
import urllib.request
import json
import re
import time
import requests
from bs4 import BeautifulSoup
import xbmcplugin
import xbmcaddon
import xbmcgui
import locale
from datetime import datetime



class MovEventScrapper:

    

    def __init__(self):
        self.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}    

    def getFutbolEvents(self, categorias):
        listaHorarios = []
        listaPartidos = []
        listaCanales = []

        print ("categorias", categorias)

        if ("futbol_primera" in categorias):
            listaHorarios_liga, listaPartidos_liga, listaCanales_liga = self.obtener_eventos_movistar_liga()
            listaHorarios = listaHorarios + listaHorarios_liga
            listaPartidos = listaPartidos + listaPartidos_liga
            listaCanales =  listaCanales + listaCanales_liga
        
        if ("futbol_segunda" in categorias):
            listaHorarios_segunda, listaPartidos_segunda, listaCanales_segunda = self.obtener_eventos_movistar_segunda()
            listaHorarios = listaHorarios + listaHorarios_segunda
            listaPartidos = listaPartidos + listaPartidos_segunda
            listaCanales =  listaCanales + listaCanales_segunda
        
        if ("futbol_champions" in categorias):
            listaHorarios_champions, listaPartidos_champions, listaCanales_champions = self.obtener_eventos_movistar_champions()
            listaHorarios = listaHorarios + listaHorarios_champions
            listaPartidos = listaPartidos + listaPartidos_champions
            listaCanales =  listaCanales + listaCanales_champions
        
        if ("futbol_europa" in categorias):
            listaHorarios_europa, listaPartidos_europa, listaCanales_europa = self.obtener_eventos_movistar_europa()
            listaHorarios = listaHorarios + listaHorarios_europa
            listaPartidos = listaPartidos + listaPartidos_europa
            listaCanales =  listaCanales + listaCanales_europa
        
        
        if ("futbol_copa" in categorias):
            listaHorarios_copa, listaPartidos_copa, listaCanales_copa = self.obtener_eventos_movistar_copa()
            listaHorarios = listaHorarios + listaHorarios_copa
            listaPartidos = listaPartidos + listaPartidos_copa
            listaCanales =  listaCanales + listaCanales_copa
        
        if ("futbol_premier" in categorias):
            listaHorarios_premier, listaPartidos_premier, listaCanales_premier = self.obtener_eventos_movistar_premier()
            listaHorarios = listaHorarios + listaHorarios_premier
            listaPartidos = listaPartidos + listaPartidos_premier
            listaCanales =  listaCanales + listaCanales_premier
        
            
        #listaHorarios =  listaHorarios_liga + listaHorarios_segunda + listaHorarios_champions + listaHorarios_copa + listaHorarios_premier
        #listaPartidos =  listaPartidos_liga + listaPartidos_segunda + listaPartidos_champions + listaPartidos_copa + listaPartidos_premier
        #listaCanales =   listaCanales_liga + listaCanales_segunda + listaCanales_champions + listaCanales_copa + listaCanales_premier
        #listaCategoria = listaCategoria_liga + listaCategoria_Segunda + listaCategoria_champions + listaCategoria_copa + listaCategoria_premier

        
        return listaHorarios, listaPartidos, listaCanales
    

    def getBasketEvents(self, categorias):
        
        listaHorarios, listaPartidos, listaCanales = self.obtener_eventos_movistar_baloncesto()

        return listaHorarios, listaPartidos, listaCanales
    
    def getMotosEvents(self, categorias):
        
        listaHorarios, listaPartidos, listaCanales = self.obtener_eventos_movistar_Motociclismo()

        return listaHorarios, listaPartidos, listaCanales
    
    def getFormulaEvents(self, categorias):
        
        listaHorarios, listaPartidos, listaCanales = self.obtener_eventos_movistar_Formula()

        return listaHorarios, listaPartidos, listaCanales
    
    def getNFLEvents(self, categorias):
        
        listaHorarios, listaPartidos, listaCanales = self.obtener_eventos_movistar_NFL()

        return listaHorarios, listaPartidos, listaCanales
    
    def getTenisvents(self, categorias):
        
        listaHorarios, listaPartidos, listaCanales = self.obtener_eventos_movistar_tenis()

        return listaHorarios, listaPartidos, listaCanales
    

    def obtener_eventos_movistar_champions(self):
        URL = "https://www.movistarplus.es/deportesendirectobar"

        page = requests.get(URL, headers=self.headers)
        html  = BeautifulSoup(page.content, "html.parser")

        listaPartidos = list()
        listaCanales = list()
        listaHorarios = list()

        container_html = html.find_all("a", string=re.compile("UEFA Champions League"))

        #print(container_html)

        for bloque in container_html:

        
            partido = bloque.string
            canal_hora = list(bloque.parent.find("li").strings)
            canal = canal_hora[0]
            hora = canal_hora[1]

            string_date = bloque.parent.parent.parent.parent.find('span', class_="fecha-bar").string + " a las " + hora
            string_date = string_date[string_date.index(" ")+1:].replace(u'enero', u'01').replace(u'febrero', u'02').replace(u'marzo', u'03').replace(u'abil', u'04').replace(u'mayo', u'05').replace(u'junio', u'06').replace(u'julio', u'07').replace(u'agosto', u'08').replace(u'septiembre', u'09').replace(u'octubre', u'10').replace(u'noviembre', u'11').replace(u'diciembre', u'12')

            format = '%d de %m de %Y a las %H.%Mh'
            try:
                fecha_hora = datetime.strptime(string_date, format)
            except TypeError:
                fecha_hora = datetime(*(time.strptime(string_date, format)[0:6]))

            listaHorarios.append(fecha_hora.strftime('%d/%m %H:%Mh'))
            listaPartidos.append(partido.replace(u'UEFA Champions League (T24/25)', u'CHAMPIONS'))
            listaCanales.append(canal[canal.index("Dial")+5:-2])            

            #print(fecha_hora.strftime('%d/%m %H:%Mh') + " - " + partido.replace(u'UEFA Champions League (T24/25)', u'CHAMPIONS') + " - " + canal[canal.index("Dial")+5:-2]) 
     

        return listaHorarios, listaPartidos, listaCanales
    

    def obtener_eventos_movistar_europa(self):
        URL = "https://www.movistarplus.es/deportesendirectobar"

        page = requests.get(URL, headers=self.headers)
        html  = BeautifulSoup(page.content, "html.parser")

        listaPartidos = list()
        listaCanales = list()
        listaHorarios = list()

        container_html = html.find_all("a", string=re.compile("UEFA Europa League"))

        #print(container_html)

        for bloque in container_html:

        
            partido = bloque.string
            canal_hora = list(bloque.parent.find("li").strings)
            canal = canal_hora[0]
            hora = canal_hora[1]

            string_date = bloque.parent.parent.parent.parent.find('span', class_="fecha-bar").string + " a las " + hora
            string_date = string_date[string_date.index(" ")+1:].replace(u'enero', u'01').replace(u'febrero', u'02').replace(u'marzo', u'03').replace(u'abil', u'04').replace(u'mayo', u'05').replace(u'junio', u'06').replace(u'julio', u'07').replace(u'agosto', u'08').replace(u'septiembre', u'09').replace(u'octubre', u'10').replace(u'noviembre', u'11').replace(u'diciembre', u'12')

            format = '%d de %m de %Y a las %H.%Mh'
            try:
                fecha_hora = datetime.strptime(string_date, format)
            except TypeError:
                fecha_hora = datetime(*(time.strptime(string_date, format)[0:6]))

            listaHorarios.append(fecha_hora.strftime('%d/%m %H:%Mh'))
            listaPartidos.append(partido.replace(u'UEFA Europa League (T24/25)', u'EUROPA'))
            listaCanales.append(canal[canal.index("Dial")+5:-2])            

            #print(fecha_hora.strftime('%d/%m %H:%Mh') + " - " + partido.replace(u'UEFA Champions League (T24/25)', u'CHAMPIONS') + " - " + canal[canal.index("Dial")+5:-2]) 
     

        return listaHorarios, listaPartidos, listaCanales
    
    def obtener_eventos_movistar_premier(self):
        URL = "https://www.movistarplus.es/deportesendirectobar"

        page = requests.get(URL, headers=self.headers)
        html  = BeautifulSoup(page.content, "html.parser")

        listaPartidos = list()
        listaCanales = list()
        listaHorarios = list()

        container_html = html.find_all("a", string=re.compile("Premier League"))

        #print(container_html)

        for bloque in container_html:

        
            partido = bloque.string
            canal_hora = list(bloque.parent.find("li").strings)
            canal = canal_hora[0]
            hora = canal_hora[1]

            string_date = bloque.parent.parent.parent.parent.find('span', class_="fecha-bar").string + " a las " + hora
            string_date = string_date[string_date.index(" ")+1:].replace(u'enero', u'01').replace(u'febrero', u'02').replace(u'marzo', u'03').replace(u'abil', u'04').replace(u'mayo', u'05').replace(u'junio', u'06').replace(u'julio', u'07').replace(u'agosto', u'08').replace(u'septiembre', u'09').replace(u'octubre', u'10').replace(u'noviembre', u'11').replace(u'diciembre', u'12')

            format = '%d de %m de %Y a las %H.%Mh'
            try:
                fecha_hora = datetime.strptime(string_date, format)
            except TypeError:
                fecha_hora = datetime(*(time.strptime(string_date, format)[0:6]))

            listaHorarios.append(fecha_hora.strftime('%d/%m %H:%Mh'))
            listaPartidos.append(partido.replace(u' (T24/25)', u''))
            listaCanales.append(canal[canal.index("Dial")+5:-2])
            

            #print(fecha_hora.strftime('%d/%m %H:%Mh') + " - " + partido.replace(u'UEFA Champions League (T24/25)', u'CHAMPIONS') + " - " + canal[canal.index("Dial")+5:-2]) 
     

        return listaHorarios, listaPartidos, listaCanales


    def obtener_eventos_movistar_segunda(self):
        URL = "https://www.movistarplus.es/deportesendirectobar"

        page = requests.get(URL, headers=self.headers)
        html  = BeautifulSoup(page.content, "html.parser")

        listaPartidos = list()
        listaCanales = list()
        listaHorarios = list()

        container_html = html.find_all("a", string=re.compile("LaLiga HyperMotion"))

        #print(container_html)

        for bloque in container_html:

        
            partido = bloque.string
            canal_hora = list(bloque.parent.find("li").strings)
            canal = canal_hora[0]
            hora = canal_hora[1]

            string_date = bloque.parent.parent.parent.parent.find('span', class_="fecha-bar").string + " a las " + hora
            string_date = string_date[string_date.index(" ")+1:].replace(u'enero', u'01').replace(u'febrero', u'02').replace(u'marzo', u'03').replace(u'abil', u'04').replace(u'mayo', u'05').replace(u'junio', u'06').replace(u'julio', u'07').replace(u'agosto', u'08').replace(u'septiembre', u'09').replace(u'octubre', u'10').replace(u'noviembre', u'11').replace(u'diciembre', u'12')

            format = '%d de %m de %Y a las %H.%Mh'
            try:
                fecha_hora = datetime.strptime(string_date, format)
            except TypeError:
                fecha_hora = datetime(*(time.strptime(string_date, format)[0:6]))

            listaHorarios.append(fecha_hora.strftime('%d/%m %H:%Mh'))
            listaPartidos.append(partido.replace(u' (T24/25)', u''))
            listaCanales.append(canal[canal.index("Dial")+5:-2])
            

            #print(fecha_hora.strftime('%d/%m %H:%Mh') + " - " + partido.replace(u'UEFA Champions League (T24/25)', u'CHAMPIONS') + " - " + canal[canal.index("Dial")+5:-2]) 
     

        return listaHorarios, listaPartidos, listaCanales 
    

    def obtener_eventos_movistar_copa(self):
        URL = "https://www.movistarplus.es/deportesendirectobar"

        page = requests.get(URL, headers=self.headers)
        html  = BeautifulSoup(page.content, "html.parser")

        listaPartidos = list()
        listaCanales = list()
        listaHorarios = list()

        container_html = html.find_all("a", string=re.compile("Copa del Rey"))

        #print(container_html)

        for bloque in container_html:

        
            partido = bloque.string
            canal_hora = list(bloque.parent.find("li").strings)
            canal = canal_hora[0]
            hora = canal_hora[1]

            string_date = bloque.parent.parent.parent.parent.find('span', class_="fecha-bar").string + " a las " + hora
            string_date = string_date[string_date.index(" ")+1:].replace(u'enero', u'01').replace(u'febrero', u'02').replace(u'marzo', u'03').replace(u'abil', u'04').replace(u'mayo', u'05').replace(u'junio', u'06').replace(u'julio', u'07').replace(u'agosto', u'08').replace(u'septiembre', u'09').replace(u'octubre', u'10').replace(u'noviembre', u'11').replace(u'diciembre', u'12')

            format = '%d de %m de %Y a las %H.%Mh'
            try:
                fecha_hora = datetime.strptime(string_date, format)
            except TypeError:
                fecha_hora = datetime(*(time.strptime(string_date, format)[0:6]))

            listaHorarios.append(fecha_hora.strftime('%d/%m %H:%Mh'))
            listaPartidos.append(partido.replace(u' (T24/25)', u''))
            listaCanales.append(canal[canal.index("Dial")+5:-2])
            

            #print(fecha_hora.strftime('%d/%m %H:%Mh') + " - " + partido.replace(u'UEFA Champions League (T24/25)', u'CHAMPIONS') + " - " + canal[canal.index("Dial")+5:-2]) 
     

        return listaHorarios, listaPartidos, listaCanales


    def obtener_eventos_movistar_liga(self):
        URL = "https://www.movistar.es/tv/agenda-deportiva/calendario-laliga-futbol-partidos-televisados/"

        page = requests.get(URL, headers=self.headers)
        html  = BeautifulSoup(page.content, "html.parser")

        listaPartidos = list()
        listaCanales = list()
        listaHorarios = list()

        container_html = html.find("div",attrs={'content-tree-alias':"tables-conts"})

        horarios_html = container_html.find_all("div", class_="movistarText")
        a = 1
        for horario in horarios_html:
            a = a + 1
            hora = horario.find("p", class_="font-size--tp3")
            if (a % 3 == 0 and hora is not None):
                listaHorarios.append(hora.string.replace(u'\xa0 ', u' '))
            

        partidos_html = container_html.find_all("h3")
        for partido in partidos_html:
            listaPartidos.append("LIGA: " + partido.string)

        canales_html = container_html.find_all("p", string="Dial:")
        for canal in canales_html:
            listaCanales.append(canal.parent.find("p", class_="font-size--tp3").string)


        return listaHorarios, listaPartidos, listaCanales, 


    def obtener_eventos_movistar_baloncesto(self):
        URL = "https://www.movistarplus.es/deportesendirectobar"

        page = requests.get(URL, headers=self.headers)
        html  = BeautifulSoup(page.content, "html.parser")

        listaPartidos = list()
        listaCanales = list()
        listaHorarios = list()

        container_html = html.find_all("span", string="Baloncesto")

        for contenedor in container_html:

            ul = contenedor.find_next_sibling("ul")
            li_list = ul.find_all("li",recursive=False)

            for item in li_list:

                partido = item.find("a").string
                canal_hora = list(item.find("li", class_="time-bar").strings)
                canal = canal_hora[0]
                hora = canal_hora[1]

                string_date = item.parent.parent.parent.find('span', class_="fecha-bar").string + " a las " + hora
                string_date = string_date[string_date.index(" ")+1:].replace(u'enero', u'01').replace(u'febrero', u'02').replace(u'marzo', u'03').replace(u'abil', u'04').replace(u'mayo', u'05').replace(u'junio', u'06').replace(u'julio', u'07').replace(u'agosto', u'08').replace(u'septiembre', u'09').replace(u'octubre', u'10').replace(u'noviembre', u'11').replace(u'diciembre', u'12')

                format = '%d de %m de %Y a las %H.%Mh'
                try:
                    fecha_hora = datetime.strptime(string_date, format)
                except TypeError:
                    fecha_hora = datetime(*(time.strptime(string_date, format)[0:6]))

                listaHorarios.append(fecha_hora.strftime('%d/%m %H:%Mh'))
                listaPartidos.append(partido.replace(u' (T24/25)', u''))
                listaCanales.append(canal[canal.index("Dial")+5:-2])

        return listaHorarios, listaPartidos, listaCanales
    

    
    def obtener_eventos_movistar_Formula(self):
        URL = "https://www.movistarplus.es/deportesendirectobar"

        page = requests.get(URL, headers=self.headers)
        html  = BeautifulSoup(page.content, "html.parser")

        listaPartidos = list()
        listaCanales = list()
        listaHorarios = list()

        container_html = html.find_all("a", string=re.compile("Mundial de Fórmula 1"))

        #print(container_html)

        for bloque in container_html:

        
            partido = bloque.string
            canal_hora = list(bloque.parent.find("li").strings)
            canal = canal_hora[0]
            hora = canal_hora[1]

            string_date = bloque.parent.parent.parent.parent.find('span', class_="fecha-bar").string + " a las " + hora
            string_date = string_date[string_date.index(" ")+1:].replace(u'enero', u'01').replace(u'febrero', u'02').replace(u'marzo', u'03').replace(u'abil', u'04').replace(u'mayo', u'05').replace(u'junio', u'06').replace(u'julio', u'07').replace(u'agosto', u'08').replace(u'septiembre', u'09').replace(u'octubre', u'10').replace(u'noviembre', u'11').replace(u'diciembre', u'12')

            format = '%d de %m de %Y a las %H.%Mh'
            try:
                fecha_hora = datetime.strptime(string_date, format)
            except TypeError:
                fecha_hora = datetime(*(time.strptime(string_date, format)[0:6]))

            listaHorarios.append(fecha_hora.strftime('%d/%m %H:%Mh'))
            listaPartidos.append(partido.replace(u'Mundial de Fórmula 1 (T2024): ', u''))
            listaCanales.append(canal[canal.index("Dial")+5:-2])
                 

        return listaHorarios, listaPartidos, listaCanales
    
    def obtener_eventos_movistar_Motociclismo(self):
        URL = "https://www.movistarplus.es/deportesendirectobar"

        page = requests.get(URL, headers=self.headers)
        html  = BeautifulSoup(page.content, "html.parser")

        listaPartidos = list()
        listaCanales = list()
        listaHorarios = list()

        container_html = html.find_all("span", string="Motociclismo")

        for contenedor in container_html:

            ul = contenedor.find_next_sibling("ul")
            li_list = ul.find_all("li",recursive=False)

            for item in li_list:

                partido = item.find("a").string
                canal_hora = list(item.find("li", class_="time-bar").strings)
                canal = canal_hora[0]
                hora = canal_hora[1]

                string_date = item.parent.parent.parent.find('span', class_="fecha-bar").string + " a las " + hora
                string_date = string_date[string_date.index(" ")+1:].replace(u'enero', u'01').replace(u'febrero', u'02').replace(u'marzo', u'03').replace(u'abil', u'04').replace(u'mayo', u'05').replace(u'junio', u'06').replace(u'julio', u'07').replace(u'agosto', u'08').replace(u'septiembre', u'09').replace(u'octubre', u'10').replace(u'noviembre', u'11').replace(u'diciembre', u'12')

                format = '%d de %m de %Y a las %H.%Mh'
                try:
                    fecha_hora = datetime.strptime(string_date, format)
                except TypeError:
                    fecha_hora = datetime(*(time.strptime(string_date, format)[0:6]))

                listaHorarios.append(fecha_hora.strftime('%d/%m %H:%Mh'))
                listaPartidos.append(partido.replace(u' (T2024)', u''))
                listaCanales.append(canal[canal.index("Dial")+5:-2])

        return listaHorarios, listaPartidos, listaCanales
    
    def obtener_eventos_movistar_NFL(self):
        URL = "https://www.movistarplus.es/deportesendirectobar"

        page = requests.get(URL, headers=self.headers)
        html  = BeautifulSoup(page.content, "html.parser")

        listaPartidos = list()
        listaCanales = list()
        listaHorarios = list()

        container_html = html.find_all("span", string="Fútbol americano")

        for contenedor in container_html:

            ul = contenedor.find_next_sibling("ul")
            li_list = ul.find_all("li",recursive=False)

            for item in li_list:

                partido = item.find("a").string
                canal_hora = list(item.find("li", class_="time-bar").strings)
                canal = canal_hora[0]
                hora = canal_hora[1]

                string_date = item.parent.parent.parent.find('span', class_="fecha-bar").string + " a las " + hora
                string_date = string_date[string_date.index(" ")+1:].replace(u'enero', u'01').replace(u'febrero', u'02').replace(u'marzo', u'03').replace(u'abil', u'04').replace(u'mayo', u'05').replace(u'junio', u'06').replace(u'julio', u'07').replace(u'agosto', u'08').replace(u'septiembre', u'09').replace(u'octubre', u'10').replace(u'noviembre', u'11').replace(u'diciembre', u'12')

                format = '%d de %m de %Y a las %H.%Mh'
                try:
                    fecha_hora = datetime.strptime(string_date, format)
                except TypeError:
                    fecha_hora = datetime(*(time.strptime(string_date, format)[0:6]))

                listaHorarios.append(fecha_hora.strftime('%d/%m %H:%Mh'))
                listaPartidos.append(partido.replace(u' (T24/25)', u''))
                listaCanales.append(canal[canal.index("Dial")+5:-2])

        return listaHorarios, listaPartidos, listaCanales
    
    def obtener_eventos_movistar_tenis(self):
        URL = "https://www.movistarplus.es/deportesendirectobar"

        page = requests.get(URL, headers=self.headers)
        html  = BeautifulSoup(page.content, "html.parser")

        listaPartidos = list()
        listaCanales = list()
        listaHorarios = list()

        container_html = html.find_all("span", string="Tenis")

        for contenedor in container_html:

            ul = contenedor.find_next_sibling("ul")
            li_list = ul.find_all("li",recursive=False)

            for item in li_list:

                partido = item.find("a").string
                canal_hora = list(item.find("li", class_="time-bar").strings)
                canal = canal_hora[0]
                hora = canal_hora[1]

                string_date = item.parent.parent.parent.find('span', class_="fecha-bar").string + " a las " + hora
                string_date = string_date[string_date.index(" ")+1:].replace(u'enero', u'01').replace(u'febrero', u'02').replace(u'marzo', u'03').replace(u'abil', u'04').replace(u'mayo', u'05').replace(u'junio', u'06').replace(u'julio', u'07').replace(u'agosto', u'08').replace(u'septiembre', u'09').replace(u'octubre', u'10').replace(u'noviembre', u'11').replace(u'diciembre', u'12')

                format = '%d de %m de %Y a las %H.%Mh'
                try:
                    fecha_hora = datetime.strptime(string_date, format)
                except TypeError:
                    fecha_hora = datetime(*(time.strptime(string_date, format)[0:6]))

                listaHorarios.append(fecha_hora.strftime('%d/%m %H:%Mh'))
                listaPartidos.append(partido.replace(u' (T2024)', u''))
                listaCanales.append(canal[canal.index("Dial")+5:-2])

        return listaHorarios, listaPartidos, listaCanales


#if __name__ == '__main__':
#    print(FutbolSrapper().getData())
