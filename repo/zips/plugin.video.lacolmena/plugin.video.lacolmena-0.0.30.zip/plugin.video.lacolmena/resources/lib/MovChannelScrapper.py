import sys
import os
import urllib.request
import json
import re
import time
import requests
from bs4 import BeautifulSoup
import xbmcaddon
import xbmcgui
from datetime import datetime



class MovChannelScrapper:

    def __init__(self):
        self.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
        addon_dir = xbmcaddon.Addon().getAddonInfo('path')
        self.cache_file = os.path.join(addon_dir, 'resources', 'cache.json')
        self.url_elcano = "https://elcano.top" 
        self.url_porlaface = "https://viendoelfutbolporlaface.pages.dev/"
        self.url_plan = "https://sites.google.com/view/elplandeportes/inicio?authuser=0" 
        self.url_plan_github ="https://elplan94.github.io/hook/"
        self.url_plan_socialcreator ="https://www.socialcreator.com/elplandeportes"
        self.url_plan_telegra ="https://telegra.ph/EL-PLAN-DEPORTES-03-19"

    def cargar_cache(self):
        if os.path.exists(self.cache_file):
            with open(self.cache_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}
    
    def guardar_cache(self, enlaces, titulos):
        timestamp = time.strftime('%Y-%m-%d %H:%M:%S')  # Obtener fecha y hora actual
        cache_data = {
            'enlaces': enlaces,
            'titulos': titulos,
            'fecha': timestamp
        }
        with open(self.cache_file, 'w', encoding='utf-8') as f:
            json.dump(cache_data, f)

    def getFechaCache(self):
        cache = self.cargar_cache()
        fecha_cache = cache.get('fecha', 'Desconocida')
        return fecha_cache

    # Función para obtener la lista de proxies desde la URL
    def obtener_proxies(self, url):
        try:
            with urllib.request.urlopen(url) as response:
                proxies_json = json.loads(response.read().decode('utf-8'))
                return proxies_json['proxies']  # Devolver la lista de proxies
        except Exception as e:
            xbmcgui.Dialog().notification("Error", f"No se pudo cargar la lista de proxies: {str(e)}")
            return []

    # Filtrar proxies asiáticos
    def filtrar_proxies_asia(self, proxies):
        proxies_asia = []
        for proxy in proxies:
            ip_data = proxy.get('ip_data')  # Obtener 'ip_data' de forma segura
            if ip_data and ip_data.get('continentCode') == 'AS':
                proxies_asia.append(proxy['proxy'])
        return proxies_asia

    # Función para probar un proxy y obtener el contenido de la web
    def obtener_contenido_web_con_proxy(self, url, proxy):

        proxy_handler = urllib.request.ProxyHandler({'http': proxy, 'https': proxy})
        opener = urllib.request.build_opener(proxy_handler)
        urllib.request.install_opener(opener)

        try:
            req = urllib.request.Request(url, headers=self.headers)
            with urllib.request.urlopen(req, timeout=10) as response:
                return response.read().decode('utf-8')
        except Exception as e:
            return None  # Devolvemos None en caso de error

    # Función para obtener el contenido de la web sin proxy
    def obtener_contenido_web_sin_proxy(self, url):

        try:
            req = urllib.request.Request(url, headers=self.headers)
            with urllib.request.urlopen(req, timeout=10) as response:
                return response.read().decode('utf-8')
        except Exception as e:
            return None  # Devolvemos None en caso de error

    # Función para extraer enlaces de la página web
    def extraer_enlaces_elcano(self, html):
        enlaces = []
        titulos = []

        patrones = re.findall(r'<a href="(acestream://[^"]+)"[^>]*>(.*?)</a>', html)

        for enlace, titulo in patrones:
            nuevo_enlace = enlace.replace("acestream://", "plugin://script.module.horus?action=play&id=")
            enlaces.append(nuevo_enlace)

            #id_acestream = enlace.split("://")[1]  # Obtener solo el ID

            titulos.append(f"{titulo.strip()}")

        return enlaces, titulos
    
    def extraer_enlaces_telegra(self, html):
        enlaces = []
        titulos = []

        patrones = re.findall(r'<p>((?:(?!<(?:a|br)).)*?)</p><p>(.*?)</p>', html)
        print(patrones)

        for titulo, enlace  in patrones:
            nuevo_enlace = enlace.replace("acestream://", "plugin://script.module.horus?action=play&id=")

            if (nuevo_enlace.find("acestream://") > 0):
                nuevo_enlace = enlace.replace("acestream://", "plugin://script.module.horus?action=play&id=")
            else:
                nuevo_enlace = "plugin://script.module.horus?action=play&id=" + enlace

            enlaces.append(nuevo_enlace)

            titulos.append(f"{titulo.strip()}".replace("• ","").replace("•",""))

        return enlaces, titulos


    # Función para actualizar y descargar la lista de enlaces
    def actualizar_lista_orig(self):
        
        url_seleccionada = "https://elcano.top" #if seleccion_actualizar == 0 else "https://viendoelfutbolporlaface.pages.dev/"
        origen_seleccionado = "Principal" #if seleccion_actualizar == 0 else "Espejo"

        proxies_url = "https://api.proxyscrape.com/v4/free-proxy-list/get?request=display_proxies&proxy_format=protocolipport&format=json"
        proxies = self.obtener_proxies(proxies_url)

        if not proxies:
            xbmcgui.Dialog().notification("Error", "No se encontraron proxies.")
            return [], [], None

        # Filtrar proxies solo de Asia
        proxies_asia = self.filtrar_proxies_asia(proxies)

        # Intentar obtener el contenido de la web sin proxy
        xbmcgui.Dialog().notification("Obteniendo enlaces", "Intentando conectar a servidor sin proxy")
        contenido_html = self.obtener_contenido_web_sin_proxy(url_seleccionada)

        if contenido_html is None:  # Si no se obtuvo contenido, intentamos con los proxies asiáticos
            limite_intentos = 50  # Límite de intentos por vez
            total_proxies = len(proxies_asia)

            for i in range(0, total_proxies, limite_intentos):
                proxies_a_probar = proxies_asia[i:i + limite_intentos]  # Seleccionar un bloque de proxies
                
                for index, proxy in enumerate(proxies_a_probar):  # Enumerar los proxies
                    xbmcgui.Dialog().notification("Obteniendo enlaces", f"Usando proxy {i + index + 1} de {total_proxies}")
                    contenido_html = self.obtener_contenido_web_con_proxy(url_seleccionada, proxy)
                    
                    if contenido_html:  # Salir si se obtiene contenido
                        break
                else:  # Si no se obtuvo contenido con el bloque actual
                    continue
                break  # Salir si se obtuvo contenido

        if contenido_html is None:
            xbmcgui.Dialog().notification("Error", "No se pudo obtener contenido.")
            return [], [], None


        enlaces, titulos = self.extraer_enlaces(contenido_html)
        xbmcgui.Dialog().notification("Obteniendo enlaces", "[COLOR green]Completado![/COLOR]")
        self.guardar_cache(enlaces, titulos)


        return enlaces, titulos, origen_seleccionado
    

    def actualizar_lista(self, provider):

        if provider == "elcano":
            url_seleccionada = self.url_elcano
            function = self.extraer_enlaces_elcano
        elif provider == "viendoelfutbolporlaface":
            url_seleccionada = self.url_porlaface
            function = self.extraer_enlaces_elcano
        elif provider == "elplan (principal)":
            url_seleccionada = self.url_plan
            function = self.extraer_enlaces_elcano  
        elif provider == "elplan (github)":
            url_seleccionada = self.url_plan_github
            function = self.extraer_enlaces_elcano   
        elif provider == "elplan (telegraph)":
            url_seleccionada = self.url_plan_telegra
            function = self.extraer_enlaces_telegra  
        elif provider == "elplan (socialcreator)":
            url_seleccionada = self.url_plan_socialcreator
            function = self.extraer_enlaces_elcano
        
        origen_seleccionado = "Principal" #if seleccion_actualizar == 0 else "Espejo"

        proxies_url = "https://api.proxyscrape.com/v4/free-proxy-list/get?request=display_proxies&proxy_format=protocolipport&format=json"
        proxies = self.obtener_proxies(proxies_url)

        if not proxies:
            xbmcgui.Dialog().notification("Error", "No se encontraron proxies.")
            return [], [], None

        # Filtrar proxies solo de Asia
        proxies_asia = self.filtrar_proxies_asia(proxies)

        # Intentar obtener el contenido de la web sin proxy
        xbmcgui.Dialog().notification("Obteniendo enlaces", "Intentando conectar a servidor sin proxy")
        contenido_html = self.obtener_contenido_web_sin_proxy(url_seleccionada)

        if contenido_html is None:  # Si no se obtuvo contenido, intentamos con los proxies asiáticos
            limite_intentos = 50  # Límite de intentos por vez
            total_proxies = len(proxies_asia)

            for i in range(0, total_proxies, limite_intentos):
                proxies_a_probar = proxies_asia[i:i + limite_intentos]  # Seleccionar un bloque de proxies
                
                for index, proxy in enumerate(proxies_a_probar):  # Enumerar los proxies
                    xbmcgui.Dialog().notification("Obteniendo enlaces", f"Usando proxy {i + index + 1} de {total_proxies}")
                    contenido_html = self.obtener_contenido_web_con_proxy(url_seleccionada, proxy)
                    
                    if contenido_html:  # Salir si se obtiene contenido
                        break
                else:  # Si no se obtuvo contenido con el bloque actual
                    continue
                break  # Salir si se obtuvo contenido

        if contenido_html is None:
            xbmcgui.Dialog().notification("Error", "No se pudo obtener contenido.")
            return [], [], None


        enlaces, titulos = function(contenido_html)
        xbmcgui.Dialog().notification("Obteniendo enlaces", "[COLOR green]Completado![/COLOR]")
        self.guardar_cache(enlaces, titulos)


        return enlaces, titulos, origen_seleccionado



#if __name__ == '__main__':
#   print(MovChannelScrapper().actualizar_lista())
