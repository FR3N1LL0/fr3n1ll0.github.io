import sys
import os
import urllib.request
import json
import re
import time
import requests
from bs4 import BeautifulSoup
import xbmcaddon
import xbmcgui
import locale
from datetime import datetime, timedelta
from resources.lib import MovChannelScrapper
from resources.lib import MovEventScrapper



class ListBuilder:

    

    def __init__(self):
        self.movChannelScrapper = MovChannelScrapper.MovChannelScrapper()
        self.movEventScrapper = MovEventScrapper.MovEventScrapper()
        self.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
        self.calidades = ["Multicamara","4K","UHD", "1080", "720", "HD","SD"]
        addon_dir = xbmcaddon.Addon().getAddonInfo('path')
        self.cache_file = os.path.join(addon_dir, 'resources', 'cache.json')
        self.diales = {
            "52": ["Copa"],
            "57": ["M. LaLiga 2"],
            "54/57": ["M. LaLiga"], # Revisar 57 para M. LaLiga
            "55/58": ["DAZN LaLiga"],
            "7/54/57": ["M. LaLiga"],
            "61": ["M.L. Campeones 2"],
            "62": ["M.L. Campeones 3"],
            "63": ["M. Deportes"],
            "64": ["M. Deportes 2"],
            "65": ["M. Deportes 3"],
            "69": ["DAZN F1"],
            "75": ["tdp"],
            "164": ["Sport Tv 3"],
            "167": ["M. LaLiga 3"],
            "168": ["M. LaLiga 4"],
            "180": ["M.L. Campeones 4"],
            "181": ["M.L. Campeones 5"],
            "182": ["M.L. Campeones 6"],
            "183": ["M.L. Campeones 7"],
            "184": ["M.L. Campeones 8"],
            "191": ["M. Deportes 4"],
            "192": ["M. Deportes 5"],
            "193": ["M. Deportes 6"],
            "194": ["M. Deportes 7"],
            "300": ["La Liga BAR", "M.L. Campeones"],
            "301": ["LaLiga Smartbank"],
            "302": ["LaLiga Smartbank 2"],
            "304": ["#Vamos"], # Duda
            "305": ["#Vamos"], # Duda
            "310": ["DAZN 1"],
            "311": ["DAZN 2"],
            "PPVP 1": ["PPVP 1"], #ESPN Premium
            "PPVP 2": ["PPVP 2"], #FS Premium
            "PPVP 3": ["PPVP 3"],
            "PPVP 4": ["PPVP 4"],
        }



    def getData(self, index, categorias, provider):
        if index == "Fútbol":
            return self.getSportData(self.movEventScrapper.getFutbolEvents, 2, categorias, provider)
        elif index == "Baloncesto":
            return self.getSportData(self.movEventScrapper.getBasketEvents, 2, categorias, provider)
        elif index == "Formula 1":
            return self.getSportData(self.movEventScrapper.getFormulaEvents, 2, categorias, provider)
        elif index == "Motociclismo":
            return self.getSportData(self.movEventScrapper.getMotosEvents, 2, categorias, provider)
        elif index == "Tenis":
            return self.getSportData(self.movEventScrapper.getTenisvents, 3, categorias, provider)
        elif index == "NFL":
            return self.getSportData(self.movEventScrapper.getNFLEvents, 4, categorias, provider)
        elif index == "Canales TV":
            return self.getTV(provider)
        else:
            pass



    def reloadChannels(self, index, provider):
        if index == "Fútbol":
            self.movChannelScrapper.actualizar_lista(provider)
        elif index == "Baloncesto":
            self.movChannelScrapper.actualizar_lista(provider)
        elif index == "Formula 1":
            self.movChannelScrapper.actualizar_lista(provider)
        elif index == "Motociclismo":
            self.movChannelScrapper.actualizar_lista(provider)
        elif index == "Tenis":
            self.movChannelScrapper.actualizar_lista(provider)
        elif index == "NFL":
            self.movChannelScrapper.actualizar_lista(provider)
        elif index == "Canales TV":
            self.movChannelScrapper.actualizar_lista(provider)
        else:
            pass

    def getFechaCache(self, index):
        if index == "Fútbol":
            return self.movChannelScrapper.getFechaCache()
        elif index == "Baloncesto":
            return self.movChannelScrapper.getFechaCache()
        elif index == "Formula 1":
            return self.movChannelScrapper.getFechaCache()
        elif index == "Motociclismo":
            return self.movChannelScrapper.getFechaCache()
        elif index == "Tenis":
            return self.movChannelScrapper.getFechaCache()
        elif index == "NFL":
            return self.movChannelScrapper.getFechaCache()
        elif index == "Canales TV":
            return self.movChannelScrapper.getFechaCache()
        else:
            pass


    def getSportData(self, scrapperfunction, hours, categorias, provider):
        data = []

        cache = self.movChannelScrapper.cargar_cache()
        enlaces_cache = cache.get('enlaces', [])
        titulos_cache = cache.get('titulos', [])
        fecha_cache = cache.get('fecha', 'Desconocida')

        if enlaces_cache and titulos_cache:
            enlaces = enlaces_cache
            titulos = titulos_cache
        else:
            enlaces, titulos, _ = self.movChannelScrapper.actualizar_lista(provider)
            if not enlaces or not titulos:
                return
            
        
        listaHorarios, listaPartidos, listaCanales = scrapperfunction(categorias)



        ahora = datetime.now()

        for x in range(0,len(listaPartidos)):

            Partido = {
                "Horario": listaHorarios[x],
                "Partido": listaPartidos[x],
                "Canales": [],
                "Estado": "",
            }

            # El futbol dura 2 horas, compruebo el estado "LIVE", "PASSED", "NEXT"
            duracionpartido = timedelta(hours = hours)

            string_date = str(ahora.year)+"/"+listaHorarios[x]
            format = "%Y/%d/%m %H:%Mh"
            try:
                horario = datetime.strptime(string_date, format)
            except TypeError:
                horario = datetime(*(time.strptime(string_date, format)[0:6]))

            # PASSED
            if (horario + duracionpartido < ahora):
                Partido['Estado'] = "PASSED"
            # NEXT
            elif (horario > ahora):
                Partido['Estado'] = "NEXT"
            # LIVE
            else:
                Partido['Estado'] = "LIVE"

           
            #print(listaHorarios[x], " - ", listaPartidos[x]," - ",listaCanales[x])
            for titulo in titulos:
                Canal = {}
                if listaCanales[x] in self.diales:
                    if any(canal+" "+ext in titulo for ext in self.calidades for canal in self.diales[listaCanales[x]]):
                        Canal = {
                            "Titulo": titulo,
                            "URL": enlaces[titulos.index(titulo)]
                        }
                        Partido["Canales"].append(Canal)
            
            # Si no hay enlaces disponibles no lo añado
            if len(Partido["Canales"]) > 0: 
                data.append(Partido)
        
        
        return data
    
    def getTV(self, provider):
        data = []

        cache = self.movChannelScrapper.cargar_cache()
        enlaces_cache = cache.get('enlaces', [])
        titulos_cache = cache.get('titulos', [])
        fecha_cache = cache.get('fecha', 'Desconocida')

        if enlaces_cache and titulos_cache:
            enlaces = enlaces_cache
            titulos = titulos_cache
        else:
            enlaces, titulos, _ = self.movChannelScrapper.actualizar_lista(provider)
            if not enlaces or not titulos:
                return
        
        listaCanales = ["La1", "La1 UHD", "La 2", "La2", "M. LaLiga", "M. LaLiga 2", "M. LaLiga 3", "M. LaLiga 4", "M. LaLiga 5", "M. LaLiga 6", "La Liga BAR", "DAZN LaLiga", "DAZN LaLiga 2", "DAZN LaLiga 3", "DAZN LaLiga 4", "DAZN LaLiga 5", "LaLiga Smartbank", "LaLiga Smartbank 2", "LaLiga Smartbank 3", "LaLiga Smartbank 4", "LaLiga Smartbank 5", "LaLiga Smartbank 6", "LaLiga Smartbank 7", "LaLiga Smartbank 8", "M.Plus", "Copa", "Copa plus", "#Vamos", "#Ellas", "M. Deportes", "M. Deportes 2", "M. Deportes 3", "M. Deportes 4", "M. Deportes 5", "M. Deportes 6", "M. deportes 7", "M.L. Campeones", "M.L. Campeones 2", "M.L. Campeones 3", "M.L. Campeones 4", "M.L. Campeones 5", "M.L. Campeones 6", "M.L. Campeones 7", "M.L. Campeones 8", "M.L. Campeones 9", "M.L. Campeones 10", "M.L. Campeones 11", "M.L. Campeones 12", "M.L. Campeones 13", "M.L. Campeones 17", "M. Golf", "M. Golf2", "DAZN 1", "DAZN 2", "DAZN 3", "DAZN 4", "DAZN F1 Multicamara (Fórmula 1)", "DAZN F1 UHD (Fórmula 1)", "DAZN F1 (Fórmula 1)", "DAZN F1", "Eurosport4k", "EuroSport 1", "EuroSport 2", "GOL TV", "tdp", "Tennis Channel", "CUATRO", "BeMad", "Telecinco", "Sport Tv 1", "Sport Tv 2", "Sport Tv 3", "beIN SPORTS ñ", "Barça", "Real Madrid TV", "Dazn liga F1", "Dazn liga F2", "Dazn liga F3", "Dazn liga F4", "Wimbledon UHD", "Mundo Toro", "NBA", "VARIOS", "#0 de Movistar", "SETANTA SPORTS", "NBA USA 1", "NBA USA 2", "ESPN USA", "ESPN 2 USA", "FOX SPORTS USA", "FOX SPORTS 2 USA", "BT Sport 1 UK", "BT Sport 2 UK", "BT Sport 3 UK", "BT Sport 4 UK", "Sky Sports Arena UK", "Sky Sports PREMIER LEAGUE UK", "Sky Sports Football UK", "Sky Sports Main Event UK", "Sky Sports Plus UK", "Premier Sports 1 UK", "Premier Sports 2 UK", "RTL+ SPORT EVENT 1 [DE]", "RTL+ SPORT EVENT 2 [DE]", "RTL+ SPORT EVENT 3 [DE]", "RTL+ SPORT EVENT 4 [DE]", "RTL+ SPORT EVENT 5 [DE]", "RTL+ SPORT EVENT 6 [DE]", "Eurosport 1 [DE]", "Eurosport 2 [DE]", "BeIN Sports 1 BE", "BeIN Sports 2 BE", "BeIN Sports 3 BE", "Eleven Sports 1 PT", "Eleven Sports 2 PT", "Eleven Sports 3 PT", "Eleven Sports 4 PT", "Eleven Sports 5 PT", "Eleven Sports 6 PT", "Setanta Sports", "Setanta Sports 1", "Setanta Sports 2", "MATCH![RU]", "MATCH! Football [RU]", "MATCH! Football 2[RU]", "MATCH! Football 3[RU]", "MATCH! Prime [RU]", "Матч! Боец [RU]", "Матч! Арена [RU]", "Матч! Наш Спорт [RU]", "Матч! Игра [RU]", "PIMPLE TV[RU]", "CTAPT [RU]", "KHL [RU]", "KHL Prime [RU]", "VIASAT Sport [RU]", "Футбол [RU]", "FOX Life [RU]", "FOX [RU]", "EuroSport 1 [RU]", "EuroSport 2 [RU]", "Qazsport [KZ]", "SETANTA Sports 1 [UA]", "SETANTA Sports 2 [UA]", "SETANTA Sports +HD[UA]", "TVP Sport [PL]", "Eleven Sports 1 [PL]", "Eleven Sports 2 [PL]", "Eleven Sports 3 [PL]", "Eleven Sports 4 [PL]", "Extreme Sports[PL]", "TVP 1 Poland", "Sport Klub[PL]", "Polsat Sport Premium 1[PL]", "Polsat Sport Premium 2[PL]", "Polsat Sport[PL]", "Polsat Sport Extra[PL]", "Canal+ Sports [PL]", "Canal+ Sports 2 [PL]", "Canal+ Sports 3 [PL]", "Canal+ Sports 5 [PL]", "FOX Comedy [PL]", "FOX [PL]", "DAZN 1 Bar [DE]", "DAZN 2 Bar [DE]", "ZDF [DE]", "ATV [DE]", "ORF 1 [DE]", "ORF 2 [DE]", "ORF 3 [DE]", "ORF Sport+ [DE]", "SkySport F1 [DE]", "Sport Digital [DE]", "Sport1+HD [DE]", "Servus TV [DE]", "Magenta Sport 1 [DE]", "Magenta Sport 2 [DE]", "Magenta Sport 3 [DE]", "Magenta Sport 4 [DE]", "Magenta Sport 5 [DE]", "Magenta Sport 6 [DE]", "Magenta Sport 7 [DE]", "Magenta Sport 8 [DE]", "Magenta Sport 9 [DE]", "Magenta Sport 10 [DE]", "Magenta Sport 11 [DE]", "BBC ONE [UK]", "Sky Sports F1[UK]", "Sky Sports Main Event [UK]", "Sky Sports Premier League[UK]", "Sky Sports[UK]", "Sky Sports Arena[UK]", "Sky Sport Cricket [UK]", "BT Sport 1 [UK]", "BT Sport 2 [UK]", "BT Sport 3 [UK]", "BT Sport 4 [UK]", "F1 TV", "Eleven TR Sport [IT]", "TeleSud Trapani [IT]", "La7 .it [IT]", "La7d .it [IT]", "ReteVeneta [IT]", "Videolina [IT]", "RTC TeleCalabria [IT]", "San Marino RTV Sport [IT]", "San Marino RTV [IT]", "teleMonteneve [IT]", "Italia 2 TV [IT]", "Canale 2 [IT]", "Canale 7 [IT]", "Milano Pavia TV [IT]", "UniNettuno University TV [IT]", "ESPN[US]", "ESPN 2[US]", "FOX Sports 1 [US]", "FOX Sports 2 [US]", "beIN Sports Xtra Ñ", "ESPN [CO]", "ESPN 2 [CO]", "ESPN 3 [CO]", "ESPN EXTRA [CO]", "Eleven Sports 1 [PT]", "Eleven Sports 2 [PT]", "Eleven Sports 3 [PT]", "Eleven Sports 4 [PT]", "Eleven Sports 5 [PT]", "Eleven Sports 6 [PT]", "Sport Tv 1 [PT]", "Sport Tv 2 [PT]", "Sport Tv 3 [PT]", "beIN Sports 1 [FR]", "beIN Sports 2 [FR]", "beIN Sports 3 [FR]", "Digi Sport 1[RM]", "Digi Sport 2[RM]", "Digi Sport 3[RM]", "Digi Sport 4[RM]", "ESPN [NL]", "Ziggo Sport Select[NL]", "Ziggo Sport Voetbal[NL]", "Ziggo Sport Racing[NL]", "Ziggo Sport Golf[NL]", "Diema Sport 2[BG]", "beIN Sports HABER [TR]", "beIN Sports 1[TR]", "beIN Sports 2[TR]", "beIN Sports 3[TR]", "beIN Sports 4[TR]", "Central TV (Perú)", "DAZN UK", "🇪🇸 EuroSport 1", "f233f3a8e9ddfae2e43d919789073fc17d9bbd7c", "c373da9e901d414b7384e671112e64d5a2310c29", "🇪🇸Eurosport 3", "🇪🇸EuroSport 4", "🇪🇸Eurosport 5", "🇪🇸EuroSport 6", "🇪🇸Eurosport 7", "🇪🇸EuroSport 8", "🇪🇸Eurosport 9", "Euro", "Euro1", "Euro2", "Euro3", "Euro4", "Euro5", "Euro6", "Euro7", "Euro8", "Euro9", "PPVP 1", "PPVP 2", "PPVP 3", "PPVP 4"]


        calidades = ["", " Multicamara"," 4K"," UHD", " 1080", " 720", " HD"," SD"]

        for x in range(0,len(listaCanales)):

            Partido = {
                "Horario": "",
                "Partido": listaCanales[x],
                "Canales": [],
                "Estado": "NEXT",
            }

           
            #print(listaHorarios[x], " - ", listaPartidos[x]," - ",listaCanales[x])
            for titulo in titulos:
                Canal = {}

                if any(listaCanales[x]+ext in titulo for ext in calidades):
                    Canal = {
                        "Titulo": titulo,
                        "URL": enlaces[titulos.index(titulo)]
                    }
                    Partido["Canales"].append(Canal)
            
            # Si no hay enlaces disponibles no lo añado
            if len(Partido["Canales"]) > 0: 
                data.append(Partido)
        
        
        return data
    