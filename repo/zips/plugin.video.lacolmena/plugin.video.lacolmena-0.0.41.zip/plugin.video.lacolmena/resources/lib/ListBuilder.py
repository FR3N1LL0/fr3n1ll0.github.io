import sys
import os
import urllib.request
import json
import re
import time
import requests
from bs4 import BeautifulSoup
import xbmcaddon
import xbmcgui
import locale
from datetime import datetime, timedelta
from resources.lib import MovChannelScrapper
from resources.lib import MovEventScrapper



class ListBuilder:

    

    def __init__(self):
        self.movChannelScrapper = MovChannelScrapper.MovChannelScrapper()
        self.movEventScrapper = MovEventScrapper.MovEventScrapper()
        self.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
        self.calidades = ["Multicamara","4K","UHD", "1080", "720", "HD","SD"]
        addon_dir = xbmcaddon.Addon().getAddonInfo('path')
        self.cache_file = os.path.join(addon_dir, 'resources', 'cache.json')
        self.diales = {
            "52": ["Copa"],
            "57": ["M. LaLiga 2"],
            "54/57": ["M. LaLiga"], # Revisar 57 para M. LaLiga
            "55/58": ["DAZN LaLiga"],
            "7/54/57": ["M. LaLiga"],
            "61": ["M.L. Campeones 2"],
            "62": ["M.L. Campeones 3"],
            "63": ["M. Deportes"],
            "64": ["M. Deportes 2"],
            "65": ["M. Deportes 3"],
            "69": ["DAZN F1"],
            "75": ["tdp"],
            "164": ["Sport Tv 3"],
            "167": ["M. LaLiga 3"],
            "168": ["M. LaLiga 4"],
            "180": ["M.L. Campeones 4"],
            "181": ["M.L. Campeones 5"],
            "182": ["M.L. Campeones 6"],
            "183": ["M.L. Campeones 7"],
            "184": ["M.L. Campeones 8"],
            "191": ["M. Deportes 4"],
            "192": ["M. Deportes 5"],
            "193": ["M. Deportes 6"],
            "194": ["M. Deportes 7"],
            "300": ["La Liga BAR", "M.L. Campeones"],
            "301": ["LaLiga Smartbank"],
            "302": ["LaLiga Smartbank 2"],
            "304": ["#Vamos"], # Duda
            "305": ["#Vamos"], # Duda
            "310": ["DAZN 1"],
            "311": ["DAZN 2"],
            "PPVP 1": ["PPVP 1"], #ESPN Premium
            "PPVP 2": ["PPVP 2"], #FS Premium
            "PPVP 3": ["PPVP 3"],
            "PPVP 4": ["PPVP 4"],
        }



    def getData(self, index, categorias, provider):
        if index == "Fútbol":
            return self.getSportData(self.movEventScrapper.getFutbolEvents, 2, categorias, provider)
        elif index == "Baloncesto":
            return self.getSportData(self.movEventScrapper.getBasketEvents, 2, categorias, provider)
        elif index == "Formula 1":
            return self.getSportData(self.movEventScrapper.getFormulaEvents, 2, categorias, provider)
        elif index == "Motociclismo":
            return self.getSportData(self.movEventScrapper.getMotosEvents, 2, categorias, provider)
        elif index == "Tenis":
            return self.getSportData(self.movEventScrapper.getTenisvents, 3, categorias, provider)
        elif index == "NFL":
            return self.getSportData(self.movEventScrapper.getNFLEvents, 4, categorias, provider)
        elif index == "Canales TV":
            return self.getTV(provider)
        else:
            pass

    def reloadChannels(self, index, provider):
        if index == "Fútbol":
            self.movChannelScrapper.actualizar_lista(provider)
        elif index == "Baloncesto":
            self.movChannelScrapper.actualizar_lista(provider)
        elif index == "Formula 1":
            self.movChannelScrapper.actualizar_lista(provider)
        elif index == "Motociclismo":
            self.movChannelScrapper.actualizar_lista(provider)
        elif index == "Tenis":
            self.movChannelScrapper.actualizar_lista(provider)
        elif index == "NFL":
            self.movChannelScrapper.actualizar_lista(provider)
        elif index == "Canales TV":
            self.movChannelScrapper.actualizar_lista(provider)
        else:
            pass

    def getFechaCache(self, index):
        if index == "Fútbol":
            return self.movChannelScrapper.getFechaCache()
        elif index == "Baloncesto":
            return self.movChannelScrapper.getFechaCache()
        elif index == "Formula 1":
            return self.movChannelScrapper.getFechaCache()
        elif index == "Motociclismo":
            return self.movChannelScrapper.getFechaCache()
        elif index == "Tenis":
            return self.movChannelScrapper.getFechaCache()
        elif index == "NFL":
            return self.movChannelScrapper.getFechaCache()
        elif index == "Canales TV":
            return self.movChannelScrapper.getFechaCache()
        else:
            pass


    def getChannels4Event(self, channels):
        data = []

        cache = self.movChannelScrapper.cargar_cache()
        enlaces_cache = cache.get('enlaces', [])
        titulos_cache = cache.get('titulos', [])

        if enlaces_cache and titulos_cache:
            enlaces = enlaces_cache
            titulos = titulos_cache
        else:
            return []

        for x in eval(channels):
            if (x in titulos):
                Canal = {
                        "Titulo": x,
                        "URL": enlaces[titulos.index(x)]
                    }
                data.append(Canal)
        
        return data
    


    def getSportData(self, scrapperfunction, hours, categorias, provider):
        data = []

        cache = self.movChannelScrapper.cargar_cache()
        enlaces_cache = cache.get('enlaces', [])
        titulos_cache = cache.get('titulos', [])
        fecha_cache = cache.get('fecha', 'Desconocida')

        if enlaces_cache and titulos_cache:
            enlaces = enlaces_cache
            titulos = titulos_cache
        else:
            enlaces, titulos, _ = self.movChannelScrapper.actualizar_lista(provider)
            if not enlaces or not titulos:
                return
            
        
        listaHorarios, listaPartidos, listaCanales = scrapperfunction(categorias)



        ahora = datetime.now()

        for x in range(0,len(listaPartidos)):

            Partido = {
                "Horario": listaHorarios[x],
                "Partido": listaPartidos[x],
                "Canales": [],
                "Estado": "",
            }

            # El futbol dura 2 horas, compruebo el estado "LIVE", "PASSED", "NEXT"
            duracionpartido = timedelta(hours = hours)

            string_date = str(ahora.year)+"/"+listaHorarios[x]
            format = "%Y/%d/%m %H:%Mh"
            try:
                horario = datetime.strptime(string_date, format)
            except TypeError:
                horario = datetime(*(time.strptime(string_date, format)[0:6]))

            # PASSED
            if (horario + duracionpartido < ahora):
                Partido['Estado'] = "PASSED"
            # NEXT
            elif (horario > ahora):
                Partido['Estado'] = "NEXT"
            # LIVE
            else:
                Partido['Estado'] = "LIVE"

           
            #print(listaHorarios[x], " - ", listaPartidos[x]," - ",listaCanales[x])
            for titulo in titulos:
                Canal = {}
                if listaCanales[x] in self.diales:
                    if any(canal+" "+ext in titulo for ext in self.calidades for canal in self.diales[listaCanales[x]]):
                        Canal = {
                            "Titulo": titulo,
                            "URL": enlaces[titulos.index(titulo)]
                        }
                        Partido["Canales"].append(Canal)
            
            # Si no hay enlaces disponibles no lo añado
            if len(Partido["Canales"]) > 0: 
                data.append(Partido)
        
        
        return data
    
    def getTV(self, provider):
        data = []

        cache = self.movChannelScrapper.cargar_cache()
        enlaces_cache = cache.get('enlaces', [])
        titulos_cache = cache.get('titulos', [])
        fecha_cache = cache.get('fecha', 'Desconocida')

        if enlaces_cache and titulos_cache:
            enlaces = enlaces_cache
            titulos = titulos_cache
        else:
            enlaces, titulos, _ = self.movChannelScrapper.actualizar_lista(provider)
            if not enlaces or not titulos:
                return
        
        listaCanales = ["La 1", "La1", "La 2", "M. LaLiga", "M. LaLiga 2", "M. LaLiga 3", "M. LaLiga 4", "M. LaLiga 5", "M. LaLiga 6", "La Liga BAR", "DAZN LaLiga", "DAZN LaLiga 2", "DAZN LaLiga 3", "DAZN LaLiga 4", "DAZN LaLiga 5", "LaLiga Smartbank", "LaLiga Smartbank 2", "LaLiga Smartbank 3", "LaLiga Smartbank 4", "LaLiga Smartbank 5", "LaLiga Smartbank 6", "LaLiga Smartbank 7", "LaLiga Smartbank 8", "M.Plus", "Copa", "Copa Plus", "#Vamos", "#Ellas", "M. Deportes", "M. Deportes 2", "M. Deportes 3", "M. Deportes 4", "M. Deportes 5", "M. Deportes 6", "M. deportes 7", "M.L. Campeones", "M.L. Campeones 2", "M.L. Campeones 3", "M.L. Campeones 4", "M.L. Campeones 5", "M.L. Campeones 6", "M.L. Campeones 7", "M.L. Campeones 8", "M.L. Campeones 9", "M.L. Campeones 10", "M.L. Campeones 11", "M.L. Campeones 12", "M.L. Campeones 13", "M. Golf", "M. Golf2", "DAZN 1", "DAZN 2", "DAZN 3", "DAZN 4", "DAZN F1 (Fórmula 1)", "EuroSport 1", "EuroSport 2", "GOL TV", "tdp", "Tennis Channel", "CUATRO", "BeMad", "Telecinco", "Sport Tv 1", "Sport Tv 2", "Sport Tv 3", "beIN SPORTS ñ", "Barça", "Real Madrid TV", "Dazn liga F1", "Dazn liga F2", "Dazn liga F3", "Dazn liga F4", "PPVP 1", "PPVP 2", "PPVP 3", "PPVP 4", "Wimbledon", "Onetoro", "NBA"]

        calidades = ["", " Multicamara"," 4K"," UHD", " 1080", " 720", " HD"," SD"]

        for x in range(0,len(listaCanales)):

            Partido = {
                "Horario": "",
                "Partido": listaCanales[x],
                "Canales": [],
                "Estado": "NEXT",
            }

           
            #print(listaHorarios[x], " - ", listaPartidos[x]," - ",listaCanales[x])
            for titulo in titulos:
                Canal = {}

                if any(listaCanales[x]+ext in titulo for ext in calidades):
                    Canal = {
                        "Titulo": titulo,
                        "URL": enlaces[titulos.index(titulo)]
                    }
                    Partido["Canales"].append(Canal)
            
            # Si no hay enlaces disponibles no lo añado
            if len(Partido["Canales"]) > 0: 
                data.append(Partido)
        
        
        return data
    