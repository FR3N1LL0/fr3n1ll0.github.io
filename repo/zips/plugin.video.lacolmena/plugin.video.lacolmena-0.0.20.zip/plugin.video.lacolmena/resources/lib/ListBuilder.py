import sys
import os
import urllib.request
import json
import re
import time
import requests
from bs4 import BeautifulSoup
import xbmcaddon
import xbmcgui
import locale
from datetime import datetime, timedelta
from resources.lib import MovChannelScrapper
from resources.lib import MovEventScrapper



class ListBuilder:

    

    def __init__(self):
        self.movChannelScrapper = MovChannelScrapper.MovChannelScrapper()
        self.movEventScrapper = MovEventScrapper.MovEventScrapper()
        self.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
        self.calidades = ["Multicamara","4K","UHD", "1080", "720", "SD"]
        addon_dir = xbmcaddon.Addon().getAddonInfo('path')
        self.cache_file = os.path.join(addon_dir, 'resources', 'cache.json')
        self.diales = {
            "52": ["Copa"],
            "57": ["M. LaLiga 2"],
            "54/57": ["M. LaLiga"], # Revisar 57 para M. LaLiga
            "55/58": ["DAZN LaLiga"],
            "7/54/57": ["M. LaLiga"],
            "61": ["M.L. Campeones 2"],
            "62": ["M.L. Campeones 3"],
            "63": ["M. Deportes"],
            "64": ["M. Deportes 2"],
            "65": ["M. Deportes 3"],
            "69": ["DAZN F1"],
            "75": ["tdp"],
            "164": ["Sport Tv 3"],
            "167": ["M. LaLiga 3"],
            "168": ["M. LaLiga 4"],
            "180": ["M.L. Campeones 4"],
            "181": ["M.L. Campeones 5"],
            "182": ["M.L. Campeones 6"],
            "183": ["M.L. Campeones 7"],
            "184": ["M.L. Campeones 8"],
            "191": ["M. Deportes 4"],
            "192": ["M. Deportes 5"],
            "193": ["M. Deportes 6"],
            "194": ["M. Deportes 7"],
            "300": ["La Liga BAR", "M.L. Campeones"],
            "301": ["LaLiga Smartbank"],
            "302": ["LaLiga Smartbank 2"],
            "304": ["#Vamos"], # Duda
            "305": ["#Vamos"], # Duda
            "310": ["DAZN 1"],
            "311": ["DAZN 2"],
            "PPVP 1": ["PPVP 1"], #ESPN Premium
            "PPVP 2": ["PPVP 2"], #FS Premium
            "PPVP 3": ["PPVP 3"],
            "PPVP 4": ["PPVP 4"],
        }



    def getData(self, index, categorias):
        if index == "Fútbol":
            return self.getSportData(self.movEventScrapper.getFutbolEvents, 2, categorias)
        elif index == "Baloncesto":
            return self.getSportData(self.movEventScrapper.getBasketEvents, 2, categorias)
        elif index == "Formula 1":
            return self.getSportData(self.movEventScrapper.getFormulaEvents, 2, categorias)
        elif index == "Motociclismo":
            return self.getSportData(self.movEventScrapper.getMotosEvents, 2, categorias)
        elif index == "Tenis":
            return self.getSportData(self.movEventScrapper.getTenisvents, 3, categorias)
        elif index == "NFL":
            return self.getSportData(self.movEventScrapper.getNFLEvents, 4, categorias)
        elif index == "Pay Per View":
            return self.getPPV()
        elif index == "Canales TV":
            return self.getTV()
        else:
            pass



    def reloadChannels(self, index):
        if index == "Fútbol":
            self.movChannelScrapper.actualizar_lista()
        elif index == "Baloncesto":
            self.movChannelScrapper.actualizar_lista()
        elif index == "Formula 1":
            self.movChannelScrapper.actualizar_lista()
        elif index == "Motociclismo":
            self.movChannelScrapper.actualizar_lista()
        elif index == "Tenis":
            self.movChannelScrapper.actualizar_lista()
        elif index == "NFL":
            self.movChannelScrapper.actualizar_lista()
        elif index == "Pay Per View":
            self.movChannelScrapper.actualizar_lista()
        elif index == "Canales TV":
            self.movChannelScrapper.actualizar_lista()
        else:
            pass

    def getFechaCache(self, index):
        if index == "Fútbol":
            return self.movChannelScrapper.getFechaCache()
        elif index == "Baloncesto":
            return self.movChannelScrapper.getFechaCache()
        elif index == "Formula 1":
            return self.movChannelScrapper.getFechaCache()
        elif index == "Motociclismo":
            return self.movChannelScrapper.getFechaCache()
        elif index == "Tenis":
            return self.movChannelScrapper.getFechaCache()
        elif index == "NFL":
            return self.movChannelScrapper.getFechaCache()
        elif index == "Pay Per View":
            return self.movChannelScrapper.getFechaCache()
        elif index == "Canales TV":
            return self.movChannelScrapper.getFechaCache()
        else:
            pass


    def getSportData(self, scrapperfunction, hours, categorias):
        data = []

        cache = self.movChannelScrapper.cargar_cache()
        enlaces_cache = cache.get('enlaces', [])
        titulos_cache = cache.get('titulos', [])
        fecha_cache = cache.get('fecha', 'Desconocida')

        if enlaces_cache and titulos_cache:
            enlaces = enlaces_cache
            titulos = titulos_cache
        else:
            enlaces, titulos, _ = self.movChannelScrapper.actualizar_lista()
            if not enlaces or not titulos:
                return
            
        
        listaHorarios, listaPartidos, listaCanales = scrapperfunction(categorias)



        ahora = datetime.now()

        for x in range(0,len(listaPartidos)):

            Partido = {
                "Horario": listaHorarios[x],
                "Partido": listaPartidos[x],
                "Canales": [],
                "Estado": "",
            }

            # El futbol dura 2 horas, compruebo el estado "LIVE", "PASSED", "NEXT"
            duracionpartido = timedelta(hours = hours)

            string_date = str(ahora.year)+"/"+listaHorarios[x]
            format = "%Y/%d/%m %H:%Mh"
            try:
                horario = datetime.strptime(string_date, format)
            except TypeError:
                horario = datetime(*(time.strptime(string_date, format)[0:6]))

            # PASSED
            if (horario + duracionpartido < ahora):
                Partido['Estado'] = "PASSED"
            # NEXT
            elif (horario > ahora):
                Partido['Estado'] = "NEXT"
            # LIVE
            else:
                Partido['Estado'] = "LIVE"

           
            #print(listaHorarios[x], " - ", listaPartidos[x]," - ",listaCanales[x])
            for titulo in titulos:
                Canal = {}
                if listaCanales[x] in self.diales:
                    if any(canal+" "+ext in titulo for ext in self.calidades for canal in self.diales[listaCanales[x]]):
                        Canal = {
                            "Titulo": titulo,
                            "URL": enlaces[titulos.index(titulo)]
                        }
                        Partido["Canales"].append(Canal)
            
            # Si no hay enlaces disponibles no lo añado
            if len(Partido["Canales"]) > 0: 
                data.append(Partido)
        
        
        return data
    
    def getTV(self):
        data = []

        cache = self.movChannelScrapper.cargar_cache()
        enlaces_cache = cache.get('enlaces', [])
        titulos_cache = cache.get('titulos', [])
        fecha_cache = cache.get('fecha', 'Desconocida')

        if enlaces_cache and titulos_cache:
            enlaces = enlaces_cache
            titulos = titulos_cache
        else:
            enlaces, titulos, _ = self.movChannelScrapper.actualizar_lista()
            if not enlaces or not titulos:
                return
        
        listaCanales = ["La1","La2","tdp", "CUATRO" ,"BeMad" ,"Telecinco" ,
                    "Eurosport4k" ,"EuroSport 1", "EuroSport 2","Euro" ,"Euro1" ,"Euro2" ,"Euro3" ,"Euro4","Euro5" ,"Euro6" ,"Euro7" ,"Euro8" ,"Euro9" ,
                    "M. LaLiga","M. LaLiga 2","M. LaLiga 3" ,"M. LaLiga 4" ,"M. LaLiga 5" ,"M. LaLiga 6" ,"La Liga BAR" ,
                    "DAZN LaLiga","DAZN LaLiga 2","DAZN LaLiga 3","DAZN LaLiga 4","DAZN LaLiga 5",
                    "LaLiga Smartbank","LaLiga Smartbank 2","LaLiga Smartbank 3""LaLiga Smartbank 4""LaLiga Smartbank 5""LaLiga Smartbank 6""LaLiga Smartbank 7""LaLiga Smartbank 8""LaLiga Smartbank 9""LaLiga Smartbank 10""LaLiga Smartbank 11""LaLiga Smartbank 12"
                    "M.Plus" ,"Copa","#Vamos","#Ellas" ,"M. Deportes","M. Deportes 2" ,"M. Deportes 3" ,"M. Deportes 4" ,"M. Deportes 5" ,"M. Deportes 6" ,"M. Deportes 7","M.L. Campeones","M.L. Campeones 2","M.L. Campeones 3" ,"M.L. Campeones 4" ,"M.L. Campeones 5" ,"M.L. Campeones 6" ,"M.L. Campeones 7" ,"M.L. Campeones 8" ,"M.L. Campeones 9" ,"M.L. Campeones 10" ,"M.L. Campeones 11" ,"M.L. Campeones 12" ,"M.L. Campeones 13" ,"M.L. Campeones 17" ,
                    "M. Golf" ,"M. Golf2" ,
                    "DAZN 1" ,"DAZN 2" ,"DAZN 3" ,"DAZN 4" ,"DAZN F1" ,
                    "GOL TV" ,
                    "Tennis Channel",
                    "Sport Tv 1" ,"Sport Tv 2" ,"Sport Tv 3" ,
                    "beIN SPORTS ñ",
                    "Barça",
                    "PPVP 1","PPVP 2","PPVP 3","PPVP 4"]

       

        for x in range(0,len(listaCanales)):

            Partido = {
                "Horario": "",
                "Partido": listaCanales[x],
                "Canales": [],
                "Estado": "NEXT",
            }

           
            #print(listaHorarios[x], " - ", listaPartidos[x]," - ",listaCanales[x])
            for titulo in titulos:
                Canal = {}

                if any(listaCanales[x]+" "+ext in titulo for ext in self.calidades):
                    Canal = {
                        "Titulo": titulo,
                        "URL": enlaces[titulos.index(titulo)]
                    }
                    Partido["Canales"].append(Canal)
            
            # Si no hay enlaces disponibles no lo añado
            if len(Partido["Canales"]) > 0: 
                data.append(Partido)
        
        
        return data

    

    def getPPV(self):
        data = []

        cache = self.movChannelScrapper.cargar_cache()
        enlaces_cache = cache.get('enlaces', [])
        titulos_cache = cache.get('titulos', [])
        fecha_cache = cache.get('fecha', 'Desconocida')

        if enlaces_cache and titulos_cache:
            enlaces = enlaces_cache
            titulos = titulos_cache
        else:
            enlaces, titulos, _ = self.movChannelScrapper.actualizar_lista()
            if not enlaces or not titulos:
                return
            

        listaCanales = ["PPVP 1", "PPVP 2", "PPVP 3", "PPVP 4"]
        for x in range(0,len(listaCanales)):

            Partido = {
                "Horario": "",
                "Partido": listaCanales[x],
                "Canales": [],
                "Estado": "NEXT",
            }

           
            #print(listaHorarios[x], " - ", listaPartidos[x]," - ",listaCanales[x])
            for titulo in titulos:
                Canal = {}
                if listaCanales[x] in self.diales:
                    if any(canal in titulo for canal in self.diales[listaCanales[x]]):
                
                        Canal = {
                            "Titulo": titulo,
                            "URL": enlaces[titulos.index(titulo)]
                        }
                        Partido["Canales"].append(Canal)
            
            # Si no hay enlaces disponibles no lo añado
            if len(Partido["Canales"]) > 0: 
                data.append(Partido)
        
        
        return data
        
    







    def getFutbolData(self):
        data = []

        cache = self.movChannelScrapper.cargar_cache()
        enlaces_cache = cache.get('enlaces', [])
        titulos_cache = cache.get('titulos', [])
        fecha_cache = cache.get('fecha', 'Desconocida')

        if enlaces_cache and titulos_cache:
            enlaces = enlaces_cache
            titulos = titulos_cache
        else:
            enlaces, titulos, _ = self.movChannelScrapper.actualizar_lista()
            if not enlaces or not titulos:
                return
        
        listaHorarios, listaPartidos, listaCanales = self.movEventScrapper.getFutbolEvents()

        ahora = datetime.now()

        for x in range(0,len(listaPartidos)):

            Partido = {
                "Horario": listaHorarios[x],
                "Partido": listaPartidos[x],
                "Canales": [],
                "Estado": "",
            }

            # El futbol dura 2 horas, compruebo el estado "LIVE", "PASSED", "NEXT"
            duracionpartido = timedelta(hours = 2)

            string_date = str(ahora.year)+"/"+listaHorarios[x]
            format = "%Y/%d/%m %H:%Mh"
            try:
                horario = datetime.strptime(string_date, format)
            except TypeError:
                horario = datetime(*(time.strptime(string_date, format)[0:6]))

            # PASSED
            if (horario + duracionpartido < ahora):
                Partido['Estado'] = "PASSED"
            # NEXT
            elif (horario > ahora):
                Partido['Estado'] = "NEXT"
            # LIVE
            else:
                Partido['Estado'] = "LIVE"

           
            #print(listaHorarios[x], " - ", listaPartidos[x]," - ",listaCanales[x])
            for titulo in titulos:
                Canal = {}
                if listaCanales[x] in self.diales:
                    if any(canal+" "+ext in titulo for ext in self.calidades for canal in self.diales[listaCanales[x]]):
                        Canal = {
                            "Titulo": titulo,
                            "URL": enlaces[titulos.index(titulo)]
                        }
                        Partido["Canales"].append(Canal)
            
            # Si no hay enlaces disponibles no lo añado
            if len(Partido["Canales"]) > 0: 
                data.append(Partido)
        
        
        return data
    
    def getBasketData(self):
        data = []

        cache = self.movChannelScrapper.cargar_cache()
        enlaces_cache = cache.get('enlaces', [])
        titulos_cache = cache.get('titulos', [])
        fecha_cache = cache.get('fecha', 'Desconocida')

        if enlaces_cache and titulos_cache:
            enlaces = enlaces_cache
            titulos = titulos_cache
        else:
            enlaces, titulos, _ = self.movChannelScrapper.actualizar_lista()
            if not enlaces or not titulos:
                return
        
        listaHorarios, listaPartidos, listaCanales = self.movEventScrapper.getBasketEvents()

        ahora = datetime.now()

        for x in range(0,len(listaPartidos)):

            Partido = {
                "Horario": listaHorarios[x],
                "Partido": listaPartidos[x],
                "Canales": [],
                "Estado": "",
            }

            # El futbol dura 2 horas, compruebo el estado "LIVE", "PASSED", "NEXT"
            duracionpartido = timedelta(hours = 2)

            string_date = str(ahora.year)+"/"+listaHorarios[x]
            format = "%Y/%d/%m %H:%Mh"
            try:
                horario = datetime.strptime(string_date, format)
            except TypeError:
                horario = datetime(*(time.strptime(string_date, format)[0:6]))

            # PASSED
            if (horario + duracionpartido < ahora):
                Partido['Estado'] = "PASSED"
            # NEXT
            elif (horario > ahora):
                Partido['Estado'] = "NEXT"
            # LIVE
            else:
                Partido['Estado'] = "LIVE"

           
            #print(listaHorarios[x], " - ", listaPartidos[x]," - ",listaCanales[x])
            for titulo in titulos:
                Canal = {}
                if listaCanales[x] in self.diales:
                    if any(canal+" "+ext in titulo for ext in self.calidades for canal in self.diales[listaCanales[x]]):
                        Canal = {
                            "Titulo": titulo,
                            "URL": enlaces[titulos.index(titulo)]
                        }
                        Partido["Canales"].append(Canal)
            
            # Si no hay enlaces disponibles no lo añado
            if len(Partido["Canales"]) > 0: 
                data.append(Partido)
        
        
        return data

    def getFormulaData(self):
        data = []

        cache = self.movChannelScrapper.cargar_cache()
        enlaces_cache = cache.get('enlaces', [])
        titulos_cache = cache.get('titulos', [])
        fecha_cache = cache.get('fecha', 'Desconocida')

        if enlaces_cache and titulos_cache:
            enlaces = enlaces_cache
            titulos = titulos_cache
        else:
            enlaces, titulos, _ = self.movChannelScrapper.actualizar_lista()
            if not enlaces or not titulos:
                return
        
        listaHorarios, listaPartidos, listaCanales = self.movEventScrapper.getFormulaEvents()

        ahora = datetime.now()

        for x in range(0,len(listaPartidos)):

            Partido = {
                "Horario": listaHorarios[x],
                "Partido": listaPartidos[x],
                "Canales": [],
                "Estado": "",
            }

            # El futbol dura 2 horas, compruebo el estado "LIVE", "PASSED", "NEXT"
            duracionpartido = timedelta(hours = 2)

            string_date = str(ahora.year)+"/"+listaHorarios[x]
            format = "%Y/%d/%m %H:%Mh"
            try:
                horario = datetime.strptime(string_date, format)
            except TypeError:
                horario = datetime(*(time.strptime(string_date, format)[0:6]))

            # PASSED
            if (horario + duracionpartido < ahora):
                Partido['Estado'] = "PASSED"
            # NEXT
            elif (horario > ahora):
                Partido['Estado'] = "NEXT"
            # LIVE
            else:
                Partido['Estado'] = "LIVE"

           
            #print(listaHorarios[x], " - ", listaPartidos[x]," - ",listaCanales[x])
            for titulo in titulos:
                Canal = {}
                if listaCanales[x] in self.diales:
                    if any(canal+" "+ext in titulo for ext in self.calidades for canal in self.diales[listaCanales[x]]):
                        Canal = {
                            "Titulo": titulo,
                            "URL": enlaces[titulos.index(titulo)]
                        }
                        Partido["Canales"].append(Canal)
            
            # Si no hay enlaces disponibles no lo añado
            if len(Partido["Canales"]) > 0: 
                data.append(Partido)
        
        
        return data
    
    def getMotosData(self):
        data = []

        cache = self.movChannelScrapper.cargar_cache()
        enlaces_cache = cache.get('enlaces', [])
        titulos_cache = cache.get('titulos', [])
        fecha_cache = cache.get('fecha', 'Desconocida')

        if enlaces_cache and titulos_cache:
            enlaces = enlaces_cache
            titulos = titulos_cache
        else:
            enlaces, titulos, _ = self.movChannelScrapper.actualizar_lista()
            if not enlaces or not titulos:
                return
        
        listaHorarios, listaPartidos, listaCanales = self.movEventScrapper.getMotosEvents()

        ahora = datetime.now()

        for x in range(0,len(listaPartidos)):

            Partido = {
                "Horario": listaHorarios[x],
                "Partido": listaPartidos[x],
                "Canales": [],
                "Estado": "",
            }

            # El futbol dura 2 horas, compruebo el estado "LIVE", "PASSED", "NEXT"
            duracionpartido = timedelta(hours = 2)

            string_date = str(ahora.year)+"/"+listaHorarios[x]
            format = "%Y/%d/%m %H:%Mh"
            try:
                horario = datetime.strptime(string_date, format)
            except TypeError:
                horario = datetime(*(time.strptime(string_date, format)[0:6]))

            # PASSED
            if (horario + duracionpartido < ahora):
                Partido['Estado'] = "PASSED"
            # NEXT
            elif (horario > ahora):
                Partido['Estado'] = "NEXT"
            # LIVE
            else:
                Partido['Estado'] = "LIVE"

           
            #print(listaHorarios[x], " - ", listaPartidos[x]," - ",listaCanales[x])
            for titulo in titulos:
                Canal = {}
                if listaCanales[x] in self.diales:
                    if any(canal+" "+ext in titulo for ext in self.calidades for canal in self.diales[listaCanales[x]]):
                        Canal = {
                            "Titulo": titulo,
                            "URL": enlaces[titulos.index(titulo)]
                        }
                        Partido["Canales"].append(Canal)
            
            # Si no hay enlaces disponibles no lo añado
            if len(Partido["Canales"]) > 0: 
                data.append(Partido)
        
        
        return data
    


#if __name__ == '__main__':
#    print(FutbolSrapper().getData())
